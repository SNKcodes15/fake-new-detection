# src/explainability.py
import joblib
import pandas as pd
from lime.lime_text import LimeTextExplainer
from pathlib import Path
from utils import ensure_dirs

ensure_dirs()
ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "baseline.pkl"
DATA = ROOT / "data" / "processed" / "dataset.csv"

def explain_sample(n=3):
    model = joblib.load(MODEL_PATH)
    df = pd.read_csv(DATA)
    texts = df["text"].tolist()
    explainer = LimeTextExplainer(class_names=["real","fake"])
    for i in range(n):
        idx = i
        text = texts[idx]
        exp = explainer.explain_instance(text, model.predict_proba, num_features=8)
        print(f"--- SAMPLE {i} ---")
        print(text[:400])
        print("Predicted prob:", model.predict_proba([text])[0])
        for feat, weight in exp.as_list():
            print(f"{feat} -> {weight:.3f}")

if __name__ == "__main__":
    explain_sample()
