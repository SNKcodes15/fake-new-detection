# src/utils.py
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def ensure_dirs():
    for p in ["data/raw", "data/processed", "models", "outputs/metrics", "outputs/figures"]:
        Path(ROOT / p).mkdir(parents=True, exist_ok=True)

def save_json(obj, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)

def load_csv(path):
    import pandas as pd
    return pd.read_csv(path)
