# src/evaluate.py
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from utils import ensure_dirs

ensure_dirs()
ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "baseline.pkl"
DATA = ROOT / "data" / "processed" / "dataset.csv"
OUT = ROOT / "outputs" / "figures"
OUT.mkdir(parents=True, exist_ok=True)

def evaluate_baseline():
    model = joblib.load(MODEL_PATH)
    df = pd.read_csv(DATA)
    X = df["text"].values
    y = df["label"].map({"real":0, "fake":1}).values
    preds = model.predict(X)
    acc = accuracy_score(y, preds)
    print("Accuracy:", acc)
    print(classification_report(y, preds, target_names=["real","fake"]))
    cm = confusion_matrix(y, preds)
    plt.figure(figsize=(5,4))
    sns.heatmap(cm, annot=True, fmt="d", xticklabels=["real","fake"], yticklabels=["real","fake"])
    plt.xlabel("Predicted"); plt.ylabel("True")
    plt.title("Confusion Matrix")
    plt.tight_layout()
    plt.savefig(OUT / "baseline_confusion.png")
    print("Saved confusion at", OUT / "baseline_confusion.png")

if __name__ == "__main__":
    evaluate_baseline()
