# src/train_transformer.py
import os
from pathlib import Path
import pandas as pd
import torch
from datasets import Dataset
from transformers import AutoTokenizer, AutoModelForSequenceClassification, TrainingArguments, Trainer, DataCollatorWithPadding
from utils import ensure_dirs

ensure_dirs()
ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "models" / "transformer"
MODEL_DIR.mkdir(parents=True, exist_ok=True)
DATA = ROOT / "data" / "processed" / "dataset.csv"

MODEL_NAME = "distilbert-base-uncased"

def load_dataset():
    df = pd.read_csv(DATA)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    df["label"] = df["label"].map({"real":0, "fake":1})
    ds = Dataset.from_pandas(df[["text","label"]])
    ds = ds.train_test_split(test_size=0.1, seed=42, stratify_by_column="label")
    return ds

def tokenize_fn(examples, tokenizer):
    return tokenizer(examples["text"], truncation=True, max_length=512)

def main():
    ds = load_dataset()
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    tokenized = ds.map(lambda x: tokenize_fn(x, tokenizer), batched=True)
    model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME, num_labels=2)
    data_collator = DataCollatorWithPadding(tokenizer)
    training_args = TrainingArguments(
        output_dir=str(MODEL_DIR),
        num_train_epochs=1,
        per_device_train_batch_size=8,
        per_device_eval_batch_size=16,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        learning_rate=2e-5,
        logging_dir=str(MODEL_DIR / "logs"),
        load_best_model_at_end=True,
        metric_for_best_model="eval_accuracy",
        fp16=torch.cuda.is_available()
    )
    def compute_metrics(eval_pred):
        from sklearn.metrics import accuracy_score, f1_score
        logits, labels = eval_pred
        preds = logits.argmax(-1)
        return {"accuracy": accuracy_score(labels, preds), "f1": f1_score(labels, preds)}
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized["train"],
        eval_dataset=tokenized["test"],
        tokenizer=tokenizer,
        data_collator=data_collator,
        compute_metrics=compute_metrics
    )
    trainer.train()
    trainer.save_model(str(MODEL_DIR / "final"))
    print("Saved transformer model to", MODEL_DIR)

if __name__ == "__main__":
    main()
