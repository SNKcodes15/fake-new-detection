# src/train_baseline.py
import joblib
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from utils import ensure_dirs

ensure_dirs()
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed" / "dataset.csv"
OUT = ROOT / "models"
OUT.mkdir(parents=True, exist_ok=True)

def load_data():
    df = pd.read_csv(DATA)
    X = df["text"].values
    y = df["label"].map({"real":0, "fake":1}).values
    return train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

def train():
    X_train, X_test, y_train, y_test = load_data()
    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(max_features=20000, ngram_range=(1,2))),
        ("clf", LogisticRegression(max_iter=1000))
    ])
    pipeline.fit(X_train, y_train)
    preds = pipeline.predict(X_test)
    acc = accuracy_score(y_test, preds)
    print("Accuracy:", acc)
    print(classification_report(y_test, preds, target_names=["real", "fake"]))
    joblib.dump(pipeline, OUT / "baseline.pkl")
    print("Saved baseline to", OUT / "baseline.pkl")
    cm = confusion_matrix(y_test, preds)
    np.save(OUT / "baseline_confusion.npy", cm)
    return pipeline

if __name__ == "__main__":
    train()
