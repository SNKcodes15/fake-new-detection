# src/data_prep.py
import re
import pandas as pd
from pathlib import Path
from utils import ensure_dirs

ensure_dirs()
ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "data" / "processed"
OUT.mkdir(parents=True, exist_ok=True)

def clean_text(text):
    if pd.isna(text):
        return ""
    text = str(text)
    text = re.sub(r"http\S+", " ", text)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^A-Za-z0-9,.!?\'\" ]+", " ", text)
    return text.strip()

def load_and_merge():
    files = list(RAW.glob("*.csv"))
    if not files:
        raise FileNotFoundError("No CSVs in data/raw. A sample CSV is included: data/raw/sample_news.csv")
    dfs = []
    for f in files:
        df = pd.read_csv(f)
        # heuristics to find text and label columns
        if "text" in df.columns:
            text_col = "text"
        elif "content" in df.columns:
            text_col = "content"
        elif "article" in df.columns:
            text_col = "article"
        elif "title" in df.columns and "text" not in df.columns:
            text_col = "title"
        else:
            text_col = next((c for c in df.columns if df[c].dtype == object), df.columns[0])
        if "label" in df.columns:
            label_col = "label"
        else:
            label_col = next((c for c in df.columns if "fake" in c.lower() or "truth" in c.lower()), None)
            if label_col is None:
                df["label"] = "unknown"
                label_col = "label"
        df2 = df[[text_col, label_col]].copy()
        df2.columns = ["text", "label"]
        dfs.append(df2)
    combined = pd.concat(dfs, ignore_index=True)
    combined["text"] = combined["text"].astype(str).map(clean_text)
    def map_label(x):
        x = str(x).lower()
        if any(s in x for s in ["fake","false","pants","unreliable"]):
            return "fake"
        if any(s in x for s in ["true","real","reliable","legit"]):
            return "real"
        if x in ["pants-fire","false","barely-true","half-true"]:
            return "fake"
        return x
    combined["label"] = combined["label"].map(map_label)
    combined = combined[combined["label"].isin(["fake","real"])]
    combined = combined.dropna(subset=["text"])
    combined = combined.sample(frac=1, random_state=42).reset_index(drop=True)
    combined.to_csv(OUT / "dataset.csv", index=False)
    print(f"Saved processed dataset to {OUT / 'dataset.csv'} with {len(combined)} rows")
    return combined

if __name__ == "__main__":
    load_and_merge()
