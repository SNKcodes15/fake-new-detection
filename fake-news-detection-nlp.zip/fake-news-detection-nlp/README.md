# 📰 Fake News Detection using NLP

A machine learning project that detects fake and real news articles using Natural Language Processing.
Includes TF-IDF + Logistic Regression baseline and a Transformer (DistilBERT) fine-tuning pipeline.

## Quick start

1. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

2. Prepare data (sample included):
```bash
python src/data_prep.py
```

3. Train baseline:
```bash
python src/train_baseline.py
```

4. Evaluate:
```bash
python src/evaluate.py
```

5. (Optional) Fine-tune transformer:
```bash
python src/train_transformer.py
```

## Project structure
```
fake-news-detection-nlp/
├── README.md
├── requirements.txt
├── .gitignore
├── data/
│   ├── raw/
│   └── processed/
├── src/
│   ├── data_prep.py
│   ├── train_baseline.py
│   ├── train_transformer.py
│   ├── evaluate.py
│   ├── explainability.py
│   └── utils.py
└── models/
```

